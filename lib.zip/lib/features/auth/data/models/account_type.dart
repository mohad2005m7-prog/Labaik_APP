// نوع الحساب اللي بيختاره المستخدم بعد تأكيد التسجيل مباشرة (شاشة "نوع الحساب")
enum AccountType { pilgrim, groupSupervisor, company }
