import '../../../../core/l10n/tx.dart';

/// نصوص شاشة نوع الحساب
abstract final class AccountTypeText {
  static const title = Tx('نوع الحساب', 'Account type');
  static const chooseFirst = Tx('يرجى اختيار نوع الحساب للمتابعة', 'Please choose an account type to continue');
  static const pilgrim = Tx('معتمر/حاج', 'Pilgrim');
  static const groupSupervisor = Tx('مشرف المجموعة', 'Group supervisor');
  static const company = Tx('الشركة', 'Company');
  static const continueLabel = Tx('متابعة', 'Continue');
  static const companyComingSoon = Tx('واجهة الشركة قريباً — نوع حسابك محفوظ', 'The company interface is coming soon — your account type is saved');
}
