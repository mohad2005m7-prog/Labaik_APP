import 'package:flutter/material.dart';

import '../../../../core/l10n/tx.dart';
import '../../../../core/theme/figma_text.dart';
import '../../../../core/utils/figma_canvas.dart';
import '../../../company/presentation/pages/company_shell.dart';
import '../../../supervisor/presentation/pages/supervisor_shell.dart';
import '../../data/account_registry.dart';
import '../../data/models/account_type.dart';
import '../../data/models/trip_setup_data.dart';
import '../controllers/auth_controller.dart';
import '../l10n/account_type_text.dart';
import '../widgets/auth_icons.dart';
import '../widgets/auth_widgets.dart';
import 'trip_type_screen.dart';

// -------------------------------------------------------------
// نوع الحساب — مطابقة لـ Figma (18:1381)، آخر الشاشات المشتركة:
// بتطلع بعد إنشاء حساب جديد وتأكيد الرمز بس (مش عند تسجيل الدخول)
// معتمر/حاج → نوع الرحلة | مشرف المجموعة → واجهة المشرف | الشركة → واجهتها لسا مش مبنية (قريباً)
// الاختيار بينحفظ فوراً للحساب (على الجهاز والسيرفر) — ما بيكمل بدون اختيار
// -------------------------------------------------------------
class AccountTypeScreen extends StatefulWidget {
  const AccountTypeScreen({super.key});

  @override
  State<AccountTypeScreen> createState() => _AccountTypeScreenState();
}

class _AccountTypeScreenState extends State<AccountTypeScreen> {
  final _data = TripSetupData.instance;

  static const _options = [
    (AccountType.pilgrim, AccountTypeText.pilgrim, AuthIcon.pilgrim),
    (AccountType.groupSupervisor, AccountTypeText.groupSupervisor, AuthIcon.supervisor),
    (AccountType.company, AccountTypeText.company, AuthIcon.company),
  ];

  Future<void> _continue() async {
    final selected = _data.accountType;
    if (selected == null) {
      AuthController.showMessage(context, AccountTypeText.chooseFirst());
      return;
    }
    await AccountRegistry.chooseType(selected);
    if (!mounted) return;

    switch (selected) {
      case AccountType.pilgrim:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const TripTypeScreen()));
      case AccountType.groupSupervisor:
        Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const SupervisorShell()), (route) => false);
      case AccountType.company:
        Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const CompanyShell()), (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthPage(
      builder: (c) => [
        // Frame 38: العنوان وسهم الرجوع ">" بنهايته (يمين بالعربي)
        authBack(c, context, left: 369, top: 72.5, width: 8, height: 15, stroke: 2),
        c.text(AccountTypeText.title(), left: 189, top: 67, width: 160, height: 26, dy: 0, style: authText(c, 20, FigmaWeight.sfBold, AuthColors.green)),

        // Figma: مربع أيقونة الخيار التاني أبعد بـ 2 عن البقية
        for (var i = 0; i < _options.length; i++) ..._option(c, top: 125 + i * 72.0, iconLeft: i == 1 ? 331.5 : 329.5, option: _options[i]),

        authButton(c, AccountTypeText.continueLabel(), left: 19, top: 357, width: 355, textSize: 19, onTap: _continue),
      ],
    );
  }

  // خيار: 363×56 — حد #1F3B2E — radius 14 — مربع الأيقونة 40×40 radius 10 بالبداية (بعد 9.5)
  List<Widget> _option(FigmaCanvas c, {required double top, required double iconLeft, required (AccountType, Tx, AuthIcon) option}) {
    final (type, label, icon) = option;
    final selected = _data.accountType == type;
    return [
      c.box(
        left: 16,
        top: top,
        width: 363,
        height: 56,
        radius: 14,
        color: selected ? const Color(0x1A4C7A75) : Colors.white,
        borderColor: AuthColors.green,
        borderWidth: selected ? 1.5 : 1,
      ),
      c.box(left: iconLeft, top: top + 7, width: 40, height: 40, radius: 10, color: Colors.white, borderColor: AuthColors.green),
      c.rect(left: iconLeft, top: top + 7, width: 40, height: 40, child: IgnorePointer(child: AuthIconView(icon, size: c.s.x(40), color: AuthColors.green))),
      c.text(label(), left: 120, top: top + 17, width: 198, height: 22, dy: 0, style: authText(c, 16, FigmaWeight.semiBold, AuthColors.green)),
      c.tapArea(left: 16, top: top, width: 363, height: 56, onTap: () => setState(() => _data.accountType = type)),
    ];
  }
}
